<?php include 'cabecera.php' ?>

<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-12 text-center">
            <img src="market-6212590_1280.png" alt="portada" width="50%">
        </div>
    </div>
</div>

<?php include 'piepagina.php'?>    